package com.acn.payments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentsInfraApplicationTests {

	@Test
	void contextLoads() {
	}

}
