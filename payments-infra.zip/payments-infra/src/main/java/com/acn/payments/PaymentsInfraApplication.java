package com.acn.payments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentsInfraApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentsInfraApplication.class, args);
	}

}
